// Node server which will handle socket io connections

const io = require('socket.io')(8000)

const users = {};

io.on('connection', socket => {
    // When a new user joins the chat conversation, let other users who are connected to the chat application know
    socket.on('new-user-joined', name => {
        console.log("New user", name);
        users[socket.id] = name;
        socket.broadcast.emit('user-joined', name);
    });
    // If the someone sends a message broadcast it to the other users
    socket.on('send', message =>{
        socket.broadcast.emit('receive', {message: message, name: users[socket.id]})
    });
    
    // If the someone leave the chat a message needs to be broadcasted as well so that other users know about it
    socket.on('disconnect', message =>{
        socket.broadcast.emit('left', users[socket.id]);
        delete users[socket.id];
    });
})